<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="section-margin-bottom section-margin-top">
    <div class="container questions-container">



        <div class="row mt-5  vh-100">
            <div class="col-md-4">

            </div>
            <div class="col-md-4 ">
                <div class="text-center">
                <img src="<?php echo e(asset('assets/images/zebra_logo.PNG')); ?>" class="d-inline-block align-top" alt="Logo">
                <h3 class="section-title text-purple mt-5">Sign Up</h3>
                <?php if(Session::has('fail')): ?> <p style="color:red;font-size:14px;"><?php echo Session::get('fail') ?></p><?php endif; ?>
                </div>

                <form action=""  method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="mb-3 mt-5">
                    <label for="exampleFormControlInput1" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"  name="first_name">
                    <?php if($errors->has("first_name")): ?> <p style="color:red;font-size:14px;"><?php echo e($errors->first('first_name')); ?></p><?php endif; ?>
                  </div>
                  <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="last_name" >
                    <?php if($errors->has("last_name")): ?> <p style="color:red;font-size:14px;"><?php echo e($errors->first('last_name')); ?></p><?php endif; ?>
                  </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1"  name="email">
                    <?php if($errors->has("email")): ?> <p style="color:red;font-size:14px;"><?php echo e($errors->first('email')); ?></p><?php endif; ?>
                  </div>
                  <div class="mb-3 ">
                    <label for="exampleFormControlInput1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleFormControlInput1"  name="password">
                    <?php if($errors->has("password")): ?> <p style="color:red;font-size:14px;"><?php echo e($errors->first('password')); ?></p><?php endif; ?>
                  </div>
                  <div class="mb-3 ">
                    <label for="exampleFormControlInput1" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="exampleFormControlInput1"  name="password_confirmation">
                    <?php if($errors->has("password_confirmation")): ?> <p style="color:red;font-size:14px;"><?php echo e($errors->first('password_confirmation')); ?></p><?php endif; ?>
                  </div>
                  <div class="text-center">
                  <button type="submit" class="yellow-btn mt-4 ">Sign Up</button>
                </div>
            </form>
                <h3 class="small-link text-purple text-start mt-5">Already have a account ? <a href="<?php echo e(url('sign-in')); ?>">Sign In</a></h3>
            </div>
            <div class="col-md-4">

            </div>
        </div>


    </div>
    </section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\zebra-brain\resources\views/user/sign_up.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="section-margin-bottom section-margin-top">
    <div class="container questions-container">
        <h3 class="section-title text-purple">Brain Test</h3>


        <div class="row mt-5">
            <div class="col-md-3">

            </div>
            <div class="col-md-6">
                <h1 class="question text-center">
                    Question 01
                </h1>
                <h1 class="question-count text-center">
                    01 out of 30
                </h1>
                <h1 class="question-title text-center mt-4">
                    <?php echo e($question->question); ?>

                </h1>
                <div class="answers-container">
                    <h1 class="question-answer text-center ">
                        <?php echo e($question->answer_1); ?>

                    </h1>
                    <h1 class="question-answer text-center ">
                        <?php echo e($question->answer_2); ?>

                    </h1>
                    <h1 class="question-answer text-center ">
                        <?php echo e($question->answer_3); ?>

                    </h1>
                    <h1 class="question-answer text-center ">
                        <?php echo e($question->answer_4); ?>

                    </h1>
                    <div class="row mt-5">
                        <div class="col-6">
                            
                        </div>
                        <div class="col-6">
                            <h3 class="nav-text text-purple text-end">Next<i class="fa-solid fa-chevron-right px-1"> </i></i></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">

            </div>
        </div>


    </div>
    </section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\wamp64\www\zebra-brain\resources\views/questions/q1.blade.php ENDPATH**/ ?>
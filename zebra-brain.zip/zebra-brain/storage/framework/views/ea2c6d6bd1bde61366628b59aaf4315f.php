<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="section-margin-bottom section-margin-top">
    <div class="container questions-container">
        <h3 class="section-title text-purple">Brain Test</h3>


        <div class="row mt-5">
            <div class="col-md-3">

            </div>
            <div class="col-md-6">
                <h1 class="question text-center">
                    Game 4 page
                </h1>


                <div class="answers-container">

                    <div class="row mt-5">


                        <div class="col-12 ">
                            <form id="myForm" action="" method="post">
                            <?php echo csrf_field(); ?>

                            <button class="question-nav text-purple" type="submit"  >Next<i class="fa-solid fa-chevron-right px-1"> </i></i></button>

                        </form>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-3">

            </div>
        </div>


    </div>
    </section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\zebra-brain\resources\views/questions/game_4.blade.php ENDPATH**/ ?>
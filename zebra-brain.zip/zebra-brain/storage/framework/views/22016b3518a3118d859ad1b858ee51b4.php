<?php echo $__env->make('layouts.dashboard-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="dashboard-page-content">
    <h3 class="section-title-big  ">Hi ! Good Evening</h3>
    <h3 class="section-title text-purple mt-5">Lets check your fucture opertunities</h3>
    <h3 class="section-title text-purple">Your Flow & Frow Tips</h3>
    <p class="section-description mt-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla molestie arcu eu finibus.</p>

    <div class="row mt-5 gx-3 gy-3">

            <div class="col-md-4" >
            <div class="row progress-container align-items-center">
                <div class="col-2" >
                    <img src="<?php echo e(asset('assets/images/zebra2.PNG')); ?>" >
                </div>
                <div class="col-8" >
                    <h3 class=" ">Multi Tasking</h3>
                    <div class="progress" style="height: 15px;">
                        <div class="progress-bar purple-progress" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                </div>
                <div class="col-2" >
                    <h3 class=" ">&nbsp; </h3>
                    <h3 class=" text-purple">70%</h3>
                </div>
            </div>
            </div>

            <div class="col-md-4" >
                <div class="row progress-container align-items-center">
                    <div class="col-2" >
                        <img src="<?php echo e(asset('assets/images/zebra2.PNG')); ?>" >
                    </div>
                    <div class="col-8" >
                        <h3 class=" ">Multi Tasking</h3>
                        <div class="progress" style="height: 15px;">
                            <div class="progress-bar purple-progress" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                    </div>
                    <div class="col-2" >
                        <h3 class=" ">&nbsp; </h3>
                        <h3 class=" text-purple">70%</h3>
                    </div>
                </div>
                </div>

                <div class="col-md-4" >
                    <div class="row progress-container align-items-center">
                        <div class="col-2" >
                            <img src="<?php echo e(asset('assets/images/zebra2.PNG')); ?>" >
                        </div>
                        <div class="col-8" >
                            <h3 class=" ">Multi Tasking</h3>
                            <div class="progress" style="height: 15px;">
                                <div class="progress-bar yellow-progress" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                              </div>
                        </div>
                        <div class="col-2" >
                            <h3 class=" ">&nbsp; </h3>
                            <h3 class=" text-purple">70%</h3>
                        </div>
                    </div>
                    </div>
                    <div class="col-md-4" >
                        <div class="row progress-container align-items-center">
                            <div class="col-2" >
                                <img src="<?php echo e(asset('assets/images/zebra2.PNG')); ?>" >
                            </div>
                            <div class="col-8" >
                                <h3 class=" ">Multi Tasking</h3>
                                <div class="progress" style="height: 15px;">
                                    <div class="progress-bar yellow-progress" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                                  </div>
                            </div>
                            <div class="col-2" >
                                <h3 class=" ">&nbsp; </h3>
                                <h3 class=" text-purple">70%</h3>
                            </div>
                        </div>
                        </div>



    </div>

    <h3 class="section-title2 text-purple mt-5">Your Flow & Frow Tips</h3>


    <div class="row mt-4 gx-3 gy-3">

        <div class="col-md-4" >
        <div class="row progress-container align-items-center">

            <div class="col-10" >
                <h3 class=" ">Multi Tasking</h3>
                <div class="progress" style="height: 15px;">
                    <div class="progress-bar purple-progress" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
            </div>
            <div class="col-2" >
                <h3 class=" ">&nbsp; </h3>
                <h3 class=" text-purple">70%</h3>
            </div>
        </div>
        </div>

        <div class="col-md-4" >

            </div>

            <div class="col-md-4" >

            </div>




</div>


<div class="row mt-4 gx-3 gy-3">

    <div class="col-md-4" >
        <div class="video-card">
        <h3 class="section-title3 text-purple">Management Skills</h3>
        <img src="<?php echo e(asset('assets/images/zebra1.PNG')); ?>" class="w-100"  >
        <div class="row">
            <div class="col-6" >
                <h3 class="text-start count mt-2">Showing 1 of 100</h3>
            </div>
            <div class="col-6" >
                <h3 class="text-end view-all mt-2 text-purple">View All</h3>
            </div>
        </div>
        </div>
    </div>

    <div class="col-md-4" >
        <div class="video-card">
        <h3 class="section-title3 text-purple">Sport Skills</h3>
        <img src="<?php echo e(asset('assets/images/zebra1.PNG')); ?>" class="w-100"  >
        <div class="row">
            <div class="col-6" >
                <h3 class="text-start count mt-2">Showing 1 of 100</h3>
            </div>
            <div class="col-6" >
                <h3 class="text-end view-all mt-2 text-purple">View All</h3>
            </div>
        </div>
        </div>
    </div>

    <div class="col-md-4" >
        <div class="video-card">
        <h3 class="section-title3 text-purple">Creative Thinking</h3>
        <img src="<?php echo e(asset('assets/images/zebra1.PNG')); ?>" class="w-100"  >
        <div class="row">
            <div class="col-6" >
                <h3 class="text-start count mt-2">Showing 1 of 100</h3>
            </div>
            <div class="col-6" >
                <h3 class="text-end view-all mt-2 text-purple">View All</h3>
            </div>
        </div>
        </div>
    </div>

    <div class="col-md-4" >
        <div class="video-card">
        <h3 class="section-title3 text-purple">Self Learning</h3>
        <img src="<?php echo e(asset('assets/images/zebra1.PNG')); ?>" class="w-100"  >
        <div class="row">
            <div class="col-6" >
                <h3 class="text-start count mt-2">Showing 1 of 100</h3>
            </div>
            <div class="col-6" >
                <h3 class="text-end view-all mt-2 text-purple">View All</h3>
            </div>
        </div>
        </div>
    </div>


</div>

<div class="row mt-5 align-items-center">
    <div class="col-md-6 text-center">
        <h3 class="section-title text-purple">Find out your child or<br> your brain !</h3>
        <button class="yellow-btn mt-4">Lets's find out </button>
    </div>
    <div class="col-md-6">
        <img src="<?php echo e(asset('assets/images/zebra1.PNG')); ?>" class="w-100">
    </div>
</div>
</div>
<?php echo $__env->make('layouts.dashboard-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\zebra-brain\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>